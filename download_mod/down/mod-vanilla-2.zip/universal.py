import os
import shutil  # Per operazioni su file e cartelle (spostare, rimuovere)
import sys     # Per uscire dallo script (sys.exit)
import requests # Per scaricare file da Internet (manifest, mod, zip)
import zipfile  # Per estrarre file .zip
import down     # Il tuo modulo personalizzato (down.py) per gestire i download delle mod
import filecmp  # Per confrontare file (usato per vedere se il manifest è cambiato)
import json     # Per leggere file JSON (il manifest e differenze.json)
import webbrowser # Per aprire il browser web (per i download manuali)
import platform

# Imposta la directory di lavoro corrente alla posizione dello script
os.chdir(os.path.dirname(os.path.abspath(__file__)))

# --- Variabili Globali ---
USER = os.getlogin()  # Ottiene il nome utente di Windows
mod = False  # Flag per sapere se è stata eseguita un'operazione sulle mod (per la pulizia finale)
# URL base su GitHub da cui scaricare i file (manifest, zip, ecc.)
GITHUB = 'https://raw.githubusercontent.com/dj2828/Ultra_Vanilla_2/main/download_mod/down/'
CUSTOMS_JAR = down.get_custom_jar_list()
WINDOWS = platform.system() == 'Windows'

def cls(): os.system('cls' if WINDOWS else 'clear')

try:
    # Funzione chiamata alla fine dello script per pulire e uscire
    def fine():
        cls()  # Pulisce la console
        try:
            shutil.rmtree('__pycache__/')  # Rimuove la cache di Python
        except:
            pass
        
        if mod:  # Se è stata fatta un'operazione sulle mod
            try:
                # Rimuove il vecchio manifest dall'istanza e il file delle differenze
                os.remove(MINECRAFT+'mods/manifest.json')
                os.remove('differenze.json')
            except:
                pass  # Ignora errori se i file non esistono
            # Sposta il nuovo manifest.json scaricato nella cartella mods
            shutil.move('manifest.json', MINECRAFT+'mods/manifest.json')

        print('\n\033[92mOra prova ad aprire ATlaunche COME OFFLINE\033[0m' if not crack else '\n\033[92mOra prova ad aprire minecarft 1.21.1 neoforge\033[0m')
        input('')  # Attende l'input dell'utente prima di chiudere
        sys.exit() # Esce dallo script

    # Funzione per scaricare e installare il texture pack
    def tx():
        print('\n\033[92mScaricamento texturepack\nAttendi...\033[0m')
        # Scarica il file zip del texture pack da GitHub
        response = requests.get(GITHUB+'Ultra-vanilla-2.zip')
        with open('Ultra-vanilla-2.zip', 'wb') as f:
            f.write(response.content)
        
        # Rimuove il vecchio texture pack se esiste
        if os.path.exists(MINECRAFT+'resourcepacks/Ultra-vanilla-2.zip'):
            os.remove(MINECRAFT+'resourcepacks/Ultra-vanilla-2.zip')
        # Crea la cartella resourcepacks se non esiste
        if not os.path.exists(MINECRAFT+'resourcepacks/'):
            os.makedirs(MINECRAFT+'resourcepacks/')
            
        # Sposta il nuovo texture pack nella cartella resourcepacks
        shutil.move('Ultra-vanilla-2.zip', MINECRAFT+'resourcepacks/')
        
        print('Texture pack installata')

        # down delle tx extra
        texturePacks = requests.get(GITHUB+'listaTx.json').json()
        for name, link in texturePacks:
            if not os.path.exists(MINECRAFT+'resourcepacks/'+name):
                response = requests.get(link)
                with open(MINECRAFT+'resourcepacks/'+name, 'wb') as f:
                    f.write(response.content)

        input('\033[92mPremere invio\033[0m ')
        
        fine() # Chiama la funzione di fine

    # Funzione per scaricare e installare "cose" (file di configurazione, ecc.)
    def cose():
        # 1. Scarica cose.zip
        response = requests.get(GITHUB + "cose.zip")
        with open("cose.zip", "wb") as f:
            f.write(response.content)
        print("\nScaricato cose.zip")

        # Pulizia preliminare della cartella temporanea se esiste già
        if os.path.exists("cosse"):
            shutil.rmtree("cosse")

        # 2. Estrae cose.zip in una cartella temporanea 'cosse'
        with zipfile.ZipFile("cose.zip", "r") as zip_ref:
            zip_ref.extractall("cosse")
        print("Cose estratte")

        # 3. Legge il file 'cose.txt' ed effettua la SOSTITUZIONE SEMPRE
        with open("./cosse/cose.txt", "r") as file:
            for line in file:
                try:
                    line = line.strip()
                    if not line:
                        continue  # Salta linee vuote

                    name, relative_dir = line.split(";")

                    # Percorso sorgente (estratto) e destinazione (Minecraft)
                    src_path = os.path.join("cosse", name)
                    dest_dir = os.path.join(MINECRAFT, relative_dir)
                    dest_path = os.path.join(dest_dir, name)

                    # --- RIMOZIONE VECCHIO ELEMENTO (Sostituzione) ---
                    if os.path.exists(dest_path):
                        if os.path.isdir(dest_path):
                            shutil.rmtree(dest_path)
                        else:
                            os.remove(dest_path)

                    # Assicura che la cartella di destinazione esista
                    os.makedirs(dest_dir, exist_ok=True)

                    # --- SPOSTAMENTO NUOVO ELEMENTO ---
                    shutil.move(src_path, dest_path)
                    print(f"Sostituito/Spostato {name} -> {dest_path}")

                except Exception as e:
                    print(f"Errore nell'elaborare la linea '{line}': {e}")

        # 4. Pulizia dei file temporanei
        if os.path.exists("cose.zip"):
            os.remove("cose.zip")
        if os.path.exists("cosse"):
            shutil.rmtree("cosse")

        # Callback finale
        if mod:
            tx()
        else:
            fine()

    def scarica_mod():
        print("\n\033[92mOra si scaricheranno le mod. premere INVIO")
        input('')
        print("Attendi...\033[0m\n")

        if crack:
            # Scarica l'installer di Forge
            with open('neoforge.jar', 'wb') as f:
                response = requests.get('https://maven.neoforged.net/releases/net/neoforged/neoforge/21.1.250/neoforge-21.1.250-installer.jar')
                f.write(response.content)
            print('Scaricato neoforge.jar')

        # Chiama la funzione 'sc' dal modulo 'down' per scaricare le mod dal manifest
        down_error, durl = down.sc(MINECRAFT+'mods/')
        # Scarica il file JAR personalizzato
        for name, url in CUSTOMS_JAR.items():
            down.scarica_file(url, MINECRAFT+'mods/'+name)

        if down_error: # Se ci sono stati errori di download
            os.system("cls")
            print("\033[91mATTENZIONE: alcune mod non sono state scaricate\033[0m")
            print("Le mod che non sono state scaricate sono:")
            for error in down_error:
                print(error)
            # Apre il browser per il download manuale
            input('\n\033[91mPremere invio per scaricarle dal browser (SE DELLE MOD DA ERRORE 404, CERCATELE E SCARICATELE TE)\033[0m')
            for i in range(len(durl)):
                print(f"{down_error[i]}: {durl[i]}\n")
                webbrowser.open(durl[i]) # Apre il link di download nel browser
            input('\n\033[91mPremere invio una volta finite di scaricare\033[0m')
            # Tenta di spostare le mod scaricate manually dalla cartella Downloads
            for i in down_error:
                try:
                    # Sposta il file dalla cartella Downloads dell'utente alla cartella mods
                    shutil.move(os.path.join(os.path.expanduser('~'), 'Downloads', i), MINECRAFT+'mods/')
                except Exception as e:
                    print(f"Errore nello spostare {i}: {e}") # Stampa un errore se lo spostamento fallisce

        if crack:
            print("\033[92mPremere INVIO\033[0m")
            input('')
            # Avvia l'installer di Forge
            print('\033[92mOra comparirà una finestra per installare forge, tu prosegui')
            input('Premi INVIO per iniziare\033[0m ')
            os.system('start '+'./neoforge.jar') # Esegue il file .jar
            print('\n\033[92mUna volta finito premi INVIO\033[0m')
            input('') # Attende che l'utente finisca l'installazione manuale
            os.remove('neoforge.jar')
            try:
                os.remove('neoforge.jar.log')
            except:
                pass

        print('Mod scaricate')
        cose() # Chiama 'cose' in modalità installazione (False)

    # Funzione per aggiornare le mod
    def upt_mod():
        print("\n\033[92mOra si aggiorneranno le mod. premere INVIO")
        input('')
        print("Attendi...\033[0m\n")

        # Confronta il manifest locale con quello nuovo e scrive le differenze in 'differenze.json'
        down.confronta_modlist(MINECRAFT+'mods/manifest.json', 'manifest.json')

        # Legge 'differenze.json'
        with open('differenze.json', "r", encoding="utf-8") as f:
            manifest = json.load(f)
            cancellare = manifest.get("cancellare", []) # Lista mod da cancellare
            aggiungere = manifest.get("aggiungere", []) # Lista mod da aggiungere

        if cancellare:
            down.cancella_mod(cancellare, MINECRAFT+'mods/') # Cancella le mod vecchie
        
        # Sposta temporaneamente 'mcef-libraries' (probabilmente per evitare che venga cancellato)
        if os.path.exists(MINECRAFT+'mods/mcef-libraries/'): shutil.move(MINECRAFT+'mods/mcef-libraries/', './mcef-libraries/')
        # Rimuove il vecchio JAR personalizzato
        for name, url in CUSTOMS_JAR.items():
            if os.path.exists(MINECRAFT+'mods/'+name): os.remove(MINECRAFT+'mods/'+name)

        # Scarica le mod nuove
        if aggiungere:
            down_error = [] # Inizializza la lista di errori
            durl = []
            down_error, durl = down.aggiungi_mod(aggiungere, MINECRAFT+'mods/')
        
        # Rimette a posto 'mcef-libraries'
        if os.path.exists('./mcef-libraries/'): shutil.move('./mcef-libraries/', MINECRAFT+'mods/mcef-libraries/')
        # Scarica il nuovo JAR personalizzato
        for name, url in CUSTOMS_JAR.items():
            down.scarica_file(url, MINECRAFT+'mods/'+name)

        if down_error: # Se ci sono stati errori di download
            print("\033[91mATTENZIONE: alcune mod non sono state scaricate\033[0m")
            print("Le mod che non sono state scaricate sono:")
            for error in down_error:
                print(error)
            # Apre il browser per il download manuale
            input('\n\033[91mPremere invio per scaricarle dal browser (SE DELLE MOD DA ERRORE 404, CERCATELE E SCARICATELE TE)\033[0m')
            for i in range(len(durl)):
                print(f"{down_error[i]}: {durl[i]}\n")
                webbrowser.open(durl[i]) # Apre il link di download nel browser
            input('\n\033[91mPremere invio una volta finite di scaricare\033[0m')
            # Tenta di spostare le mod scaricate manually dalla cartella Downloads
            for i in down_error:
                try:
                    # Sposta il file dalla cartella Downloads dell'utente alla cartella mods
                    shutil.move(os.path.join(os.path.expanduser('~'), 'Downloads', i), MINECRAFT+'mods/')
                except Exception as e:
                    print(f"Errore nello spostare {i}: {e}") # Stampa un errore se lo spostamento fallisce

        print('Mod aggiornate')

        # Chiede se aggiornare anche 'cose'
        cos = input('\n\033[92mVuoi anche aggiornare cose? (s/n) \033[0m')
        if cos == 's':
            cose()
        elif cos == 'n':
            tx() # Altrimenti aggiorna solo il texture pack

    # Funzione per riparare le mod
    def rip_mod(full):
        print("\n\033[92mOra si ripareranno le mod. premere INVIO")
        input('')
        print("Attendi...\033[0m\n")
        
        # Sposta le mod valide esistenti in una cartella temporanea './mods'
        if not full:
            da_mettere = down.rip_sposta(MINECRAFT+'mods/')
        else:
            da_mettere = down.GET_MANIFEST()

        try:
            # Rimuove la vecchia cartella mods (corrotta)
            shutil.rmtree(MINECRAFT+'mods/')
        except:
            pass
        
        # Scarica il JAR personalizzato se non è stato salvato
        for name, url in CUSTOMS_JAR.items():
            if not os.path.exists('./mods/'+name): down.scarica_file(url, './mods/'+name)
        
        if da_mettere:
            # Chiama 'sc' passando la lista delle mod MANCANTI ('da_mettere')
            down_error, durl = down.sc('./mods/', da_mettere)

            # Sposta le mod salvate (da './mods') nella nuova cartella mods
            shutil.move('./mods/', MINECRAFT+'mods/')

            if down_error: # Se ci sono stati errori di download
                print("\033[91mATTENZIONE: alcune mod non sono state scaricate\033[0m")
                print("Le mod che non sono state scaricate sono:")
                for error in down_error:
                    print(error)
                # Apre il browser per il download manuale
                input('\n\033[91mPremere invio per scaricarle dal browser (SE DELLE MOD DA ERRORE 404, CERCATELE E SCARICATELE TE)\033[0m')
                for i in range(len(durl)):
                    print(f"{down_error[i]}: {durl[i]}\n")
                    webbrowser.open(durl[i])
                input('\n\033[91mPremere invio una volta finite di scaricare\033[0m')
                # Tenta di spostare le mod scaricate manualmente dalla cartella Downloads
                for i in down_error:
                    try:
                        shutil.move(os.path.join(os.path.expanduser('~'), 'Downloads', i), MINECRAFT+'mods/')
                    except Exception as e:
                        print(f"Errore nello spostare {i}: {e}")
        else:
            # Sposta le mod salvate (da './mods') nella nuova cartella mods
            shutil.move('./mods/', MINECRAFT+'mods/')

        print('Mod riparate')
        cose()

# --- Inizio Esecuzione Script ---
    print(USER)
    print("Benvenuto nell' installer delle mod")
    print('SEI DA COSA?')
    print('1: ATlauncher\n2: Launcher normale | Tlauncher')
    cos = input('')
    crack = False if cos == '1' else True # Flag per sapere se NON è ATlauncher
    # Percorso dell'istanza di Minecraft
    if WINDOWS:
        base_dir = os.getenv('APPDATA')
        atl_path = os.path.join(base_dir, 'ATLauncher/instances/Ultravanilla2/')
        mc_path = os.path.join(base_dir, '.minecraft/')
    else:
        # Linux / macOS
        atl_path = os.path.expanduser('~/.local/share/atlauncher/instances/Ultravanilla2/')
        mc_path = os.path.expanduser('~/.minecraft/')
    MINECRAFT = mc_path if crack else atl_path

    print("\nSe devi scaricare le mod scrivi 's'\nSe devi aggiornare scrivi 'a'\nSe devi riparare le mod scrivi 'r'\nSe devi aggiornare la texture pack scrivi 'tx'\nSe devi aggiornare altre cose scrivi 'cose'")
    cos = input('') # Legge la scelta dell'utente
    cls() # Pulisce lo schermo
    
    if cos == 's': # SCARICA
        
        if not crack and not os.path.exists(MINECRAFT+'mods/'): # Controlla se la istanza ATlauncher è stata creata
            print("\033[91mCrea la istanza di Minecraft 'Neoforge 1.21.1', chiamandola '.Ultra vanilla 2'. premi INVIO\033[0m")
            input('')
            sys.exit()

        response = requests.get(GITHUB+'manifest.json') # Scarica il manifest
        with open('manifest.json', 'wb') as f:
            f.write(response.content)
        print(f'Scaricato manifest.json')

        # --- DIFFERENZA crack ---
        # Controllo di sicurezza: costringe l'utente a rimuovere la cartella mods
        # esistente prima di procedere con una nuova installazione.
        if crack:
            while os.path.exists(MINECRAFT+'mods'):
                print('\033[91mLa cartella mods esiste ancora, rinominala o cancellala. premi INVIO\033[0m')
                input('')
                os.system('start '+MINECRAFT) # Apre la cartella .minecraft
                print('Una volta fatto premi INVIO')
                input('')
            os.makedirs(MINECRAFT+'mods/') # Crea la nuova cartella mods
        # ------------------

        mod = True # Imposta il flag mod
        scarica_mod()

    elif cos == 'a': # AGGIORNA
        # Controllo di sicurezza: verifica che esista un manifest da aggiornare
        if not os.path.exists(MINECRAFT+'mods/') and not crack: # Controlla se la cartella mods esiste
            print("\033[91mLa cartella mods non esiste, quindi scegli 'scaricare'. premi INVIO\033[0m")
            input('')
            sys.exit()
        elif not os.path.exists(MINECRAFT+'mods/manifest.json') and crack:
            print("\033[91mLa cartella mods non esiste o è stata rinominata, quindi scegli 'scaricare', rinominala in 'mods' o riparare. premi INVIO\033[0m")
            input('')
            os.system('start '+MINECRAFT)
            sys.exit()
        
        response = requests.get(GITHUB+'manifest.json') # Scarica nuovo manifest
        with open('manifest.json', 'wb') as f:
            f.write(response.content)
        print(f'Scaricato manifest.json')
        mod = True # Imposta il flag mod
        
        # Confronta il nuovo manifest con quello vecchio
        if filecmp.cmp("manifest.json", MINECRAFT+'mods/manifest.json', shallow=False):
            print("\033[92mLe mod sono già aggiornate\033[0m")
            cos = input('\n\033[92mVuoi anche aggiornare cose? (s/n) \033[0m')
            if cos == 's':
                cose()
            elif cos == 'n':
                tx()
        else: # Se i manifest sono diversi, aggiorna
            upt_mod()

    elif cos == 'r': # RIPARA
        full = False
        cos = input('\n\033[92mVuoi reinstallare tutte le mod o solo scaricare quelle che non ci sono (1/2) \033[0m')
        if cos=="1":
            full = True
        response = requests.get(GITHUB+'manifest.json')
        with open('manifest.json', 'wb') as f:
            f.write(response.content)
        print(f'Scaricato manifest.json')
        mod = True
        rip_mod(full)

    elif cos == 'tx': # TEXTURE PACK
        tx()

    elif cos == 'cose': # COSE
        cose()

except SystemExit:
    raise # Permette a sys.exit() di funzionare correttamente
except Exception as e:
    # Gestione generica degli errori
    cls()
    print("\033[91mERRORE\033[0m")
    print('\033[91mChiedi a dj\033[0m')
    input(e) # Mostra l'errore e attende l'input