import os
import webbrowser
import shutil
import sys
import requests
import zipfile

global user
global agg
agg=False

try:
    def fine():
        if agg:
            try:
                os.remove('modlist.txt')
                os.remove('C:/Users/'+user+'/Downloads/forge-1.20.1-47.3.0-installer.jar')
                os.remove('forge-1.20.1-47.3.0-installer.jar.log')
            except:
                pass
            print('\n\033[92mOra prova ad aprire minecarft 1.20.1 forge 47.2.0\033[0m')
            input('')
        sys.exit()

    def tx():
        print('\033[92mAttendi...\033[0m')
        response = requests.get('https://github.com/dj2828/sito/releases/download/mod_vanilla_2/Ultra-vanilla-2.zip')
        with open('Ultra-vanilla-2.zip', 'wb') as f:
            f.write(response.content)
        
        if os.path.exists('C:/Users/'+user+'/AppData/Roaming/.minecraft/resourcepacks/Ultra-vanilla-2.zip'):
            os.remove('C:/Users/'+user+'/AppData/Roaming/.minecraft/resourcepacks/Ultra-vanilla-2.zip')
        if os.path.exists('C:/Users/'+user+'/AppData/Roaming/.minecraft/resourcepacks/') == False:
            os.makedirs('C:/Users/'+user+'/AppData/Roaming/.minecraft/resourcepacks/')
            
        shutil.move('Ultra-vanilla-2.zip', 'C:/Users/'+user+'/AppData/Roaming/.minecraft/resourcepacks/')
        
        print('Texture pack installata')
        input('\033[92mPremere invio\033[0m ')
        
        fine()

    def cose(a):
    # scarica cose
        response = requests.get('https://github.com/dj2828/sito/releases/download/mod_vanilla_2/cose.zip')
        with open('cose.zip', 'wb') as f:
            f.write(response.content)
        print('Scaricato cose.zip')

        with zipfile.ZipFile('cose.zip', 'r') as zip_ref:
            os.makedirs('cosse/')
            zip_ref.extractall('cosse/')
        print('Cose estratte')

        with open('./cosse/cose.txt', 'r') as file:
            for line in file:
                line = line.strip()
                if not line:
                    continue

                dirr = False

                operation = line[0]
                name, _ = line.split(';')
                if '.' not in name:
                    dirr = True
                if operation != '+':
                    if a:
                        continue
                    else:
                        try:
                            if dirr:
                                shutil.rmtree(dire)
                            else:
                                os.remove(dire+name)
                        except:
                            pass
                        name, dire = line.split(';')
                        dire = 'C:/Users/'+user+'/AppData/Roaming/.minecraft/'+dire
                        if dirr:
                            shutil.move('cosse/'+name, dire)
                        else:
                            if os.path.exists(dire)==False:
                                os.makedirs(dire)
                            shutil.move('cosse/'+name, dire+name)
                        print('Spostato '+name)
                else:
                    rest = line[1:]
                    name, dire = rest.split(';')
                    dire = 'C:/Users/'+user+'/AppData/Roaming/.minecraft/'+dire
                    try:
                        if dirr:
                            shutil.rmtree(dire)
                        else:
                            os.remove(dire+name)
                    except:
                        pass
                    if dirr:
                        shutil.move('cosse/'+name, dire)
                    else:
                        if os.path.exists(dire)==False:
                            os.makedirs(dire)
                        shutil.move('cosse/'+name, dire+name)
                    print('Spostato '+name)
        
        os.remove('cose.zip')
        shutil.rmtree('cosse/')
        if agg:
            tx()
        else:
            fine()

    def scarica_mod(cart_mod):
        if cart_mod == False:
            print("\n\033[92mOra si scaricheranno le mod. premere INVIO")
            input('')
            print("Attendi...\033[0m")
            webbrowser.open('https://maven.minecraftforge.net/net/minecraftforge/forge/1.20.1-47.3.0/forge-1.20.1-47.3.0-installer.jar')
            with open('modlist.txt', 'r') as file:
                for line in file:
                    line = line.strip()
                    if not line:
                        continue

                name, modlink = line.split(';')
                response = requests.get(modlink)
                with open(name + '.jar', 'wb') as f:
                    f.write(response.content)
                print(f'Scaricato {name}')

            print("\033[92mPremere INVIO\033[0m")
            input('')

# installa_forge
            print('\033[92mOra comparirà una finestra per installare forge, tu prosegui')
            input('Premi INVIO per iniziare\033[0m ')
            os.system('start '+'C:/Users/'+user+'/Downloads/forge-1.20.1-47.3.0-installer.jar')
            print('\n\033[92mUna volta finito premi INVIO\033[0m')
            input('')

# sposta_mod
        if os.path.exists('C:/Users/'+user+'/AppData/Roaming/.minecraft/mods'):
            print('\033[91mLa cartella mods esiste ancora, rinominala o cancellala. premi INVIO\033[0m')
            input('')
            os.system('start '+'C:/Users/'+user+'/AppData/Roaming/.minecraft/')
            print('Una volta fatto premi INVIO')
            input('')
            scarica_mod(True)
        else:
            os.makedirs('C:/Users/'+user+'/AppData/Roaming/.minecraft/mods/')
            
        with open('modlist.txt', 'r') as file:
            for line in file:
                line = line.strip()
                if not line:
                    continue

                name, _ = line.split(';')
                source_file = name+'.jar'
                destination_file = 'C:/Users/'+user+'/AppData/Roaming/.minecraft/mods/'+name+'.jar'
                
                if os.path.exists(source_file):
                    shutil.move(source_file, destination_file)
        print('Mod spostate')

        cose(False)


    def upt_mod():
        print("\n\033[92mOra si aggiorneranno le mod. premere INVIO")
        input('')
        print("Attendi...\033[0m")
        os.makedirs('./mods/')
        with open('modlist.txt', 'r') as file:
            for line in file:
                line = line.strip()
                if not line:
                    continue
                
                name, _ = line.split(';')

                if os.path.exists('C:/Users/'+user+'/AppData/Roaming/.minecraft/mods/'+name+'.jar'):
                    shutil.move('C:/Users/'+user+'/AppData/Roaming/.minecraft/mods/'+name+'.jar', './mods/')
                else:
                    continue
        shutil.move('C:/Users/'+user+'/AppData/Roaming/.minecraft/mods/mcef-libraries/', './mods/mcef-libraries/')

        shutil.rmtree('C:/Users/'+user+'/AppData/Roaming/.minecraft/mods/')

        # scarica quelle nuove
        with open('modlist.txt', 'r') as file:
            for line in file:
                line = line.strip()
                if not line:
                    continue

                name, modlink = line.split(';')

                if os.path.exists('./mods/'+name+'.jar') == False:
                    response = requests.get(modlink)
                    with open(name + '.jar', 'wb') as f:
                        f.write(response.content)
                    shutil.move(name+'.jar', './mods/')
                    print(f'Scaricato {name}')
                else:
                    continue
        
        shutil.move('./mods/', 'C:/Users/'+user+'/AppData/Roaming/ATLauncher/instances/Ultravanilla2/mods/')

        print('Mod aggiornate')

        cos = input('\033[92mVuoi anche aggiornare cose? (s/n) \033[0m')
        if cos == 's':
            cose(True)
        elif cos == 'n':
            tx()

    user = os.getlogin()

    print(user)
    print("Benvenuto nell' installer delle mod")
    print("Se devi scaricare le mod scrivi 's'\nSe devi aggiornare scrivi 'a'\nSe devi aggiornare la texture pack scrivi 'tx'\nSe devi aggiornare altre cose scrivi 'cose'")
    cos = input('')
    if cos == 's':
        response = requests.get('https://github.com/dj2828/sito/releases/download/mod_vanilla_2/modlist.txt')
        with open('modlist.txt', 'wb') as f:
            f.write(response.content)
        print(f'Scaricato modlist.txt')
        agg = True
        scarica_mod(False)

    elif cos == 'a':
        if os.path.exists('C:/Users/'+user+'/AppData/Roaming/.minecraft/mods/') == False:
            print("\033[91mLa cartella mods non esiste, quindi scegli 'scaricare'. premi INVIO\033[0m")
            input('')
            sys.exit()
        response = requests.get('https://github.com/dj2828/sito/releases/download/mod_vanilla_2/modlist.txt')
        with open('modlist.txt', 'wb') as f:
            f.write(response.content)
        print(f'Scaricato modlist.txt')
        agg = True
        upt_mod()

    elif cos == 'tx':
        tx()

    elif cos == 'cose':
        cose(True)
        
except SystemExit:
    raise
except:
    print("\033[91mERRORE\033[0m")
    input('\033[91mAPRI "se non worka.bat". se non va neanche quello chiedi a dj \033[0m')