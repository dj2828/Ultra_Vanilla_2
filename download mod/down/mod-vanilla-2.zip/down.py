import json
import os
import requests
import shutil

API_KEY = "$2a$10$qP3o7IaF4x.p/GmbIBVvqOHjuZ9b.4Xc2tQ91GkW/DhVZjLIuWWpK"
HEADERS = {
    "Accept": "application/json",
    "x-api-key": API_KEY
}
MANIFEST_PATH = "modlist.json"

def ottieni_link_download(project_id, file_id):
    url = f"https://api.curseforge.com/v1/mods/{project_id}/files/{file_id}/download-url"
    resp = requests.get(url, headers=HEADERS)

    if resp.status_code == 200:
        return resp.json().get("data")
    return None


def ottieni_nome_file(project_id, file_id):
    url = f"https://api.curseforge.com/v1/mods/{project_id}/files/{file_id}"
    resp = requests.get(url, headers=HEADERS)
    if resp.status_code == 200:
        return resp.json()["data"]["fileName"]
    return f"{file_id}.jar"

def scarica_file(url, percorso_file):
    resp = requests.get(url)
    with open(percorso_file, "wb") as f:
        f.write(resp.content)

def sc(MODS_DIR):
    if not os.path.exists(MODS_DIR):
        os.makedirs(MODS_DIR)

    with open(MANIFEST_PATH, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    files = manifest.get("files", [])
    print(f"🔍 Trovate {len(files)} mod nella modlist.")

    for mod in files:
        project_id = mod["projectID"]
        file_id = mod["fileID"]

        download_url = ottieni_link_download(project_id, file_id)
        if not download_url:
            print("❌ Download URL non trovato.")
            continue

        nome_file = ottieni_nome_file(project_id, file_id)
        destinazione = os.path.join(MODS_DIR, nome_file)
        scarica_file(download_url, destinazione)
        print(f"✅ Scaricato {nome_file}")

def upt_sposta(MODS_DIR):
    os.makedirs('./mods/')

    with open(MANIFEST_PATH, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    files = manifest.get("files", [])
    print(f"🔍 Trovate {len(files)} mod nella modlist.")

    shutil.move(MODS_DIR+'mods/ultra_vanilla_2.jar', './mods/')

    for mod in files:
        project_id = mod["projectID"]
        file_id = mod["fileID"]
        nome_file = ottieni_nome_file(project_id, file_id)

        if os.path.exists(MODS_DIR+nome_file):
            shutil.move(MODS_DIR+nome_file, './mods/')
        else:
            continue

def upt_down():
    with open(MANIFEST_PATH, "r", encoding="utf-8") as f:
        manifest = json.load(f)

    files = manifest.get("files", [])

    for mod in files:
        project_id = mod["projectID"]
        file_id = mod["fileID"]

        nome_file = ottieni_nome_file(project_id, file_id)
        if os.path.exists('./mods/'+nome_file):
            continue
        else:
            download_url = ottieni_link_download(project_id, file_id)
            if not download_url:
                print("❌ Download URL non trovato.")
                continue

            destinazione = os.path.join('./mods/', nome_file)
            scarica_file(download_url, destinazione)
            print(f"✅ Scaricato {nome_file}")

if __name__ == "__main__":
    print("Sei down")
    input("")